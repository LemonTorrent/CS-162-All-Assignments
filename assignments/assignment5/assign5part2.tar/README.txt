Name: Nicole Yarbrough
Date: 6/07/2020
Program Name: Assignment 5
Program Description: this program creates a linked list, allows user to add 
values to the linked list, print the link list, and calculates the amount of
prime numbers.

Note: I was not able to finish the sorting functions, so I am printing 
statements as placeholders.