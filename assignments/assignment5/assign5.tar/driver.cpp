/******************************************************
** Program: driver.cpp
** Author: Nicole Yarbrough
** Date: 06/07/2020
** Description: contains main function as well as functions
** that get input and check integers
** Input: none
** Output: none
******************************************************/

#include <iostream>
#include "./linkedlist.h"
#include "./node.h"

using namespace std;

/*******************************************************************
** Function: is_int()
** Description: This is the function where the string is checked to
** be an integer.
** Parameters: num
** Pre-Conditions: None
** Post-Conditions: None
*******************************************************************/ 
bool is_int(string num) {

	for (int i = 0; i < num.length(); i++) {
		if (num[i] < '0' or num[i] > '9')
			return false;
	}
	return true;

}

Linked_List recursive_merge(Linked_List original, int l, int m, int r){
    int n1 = m - l + 1;
    int n2 = r - m;

    int test = 100;

    if (l == r || r < 0 || l < -1){
        test = 200;
        Linked_List new_list;

        if (original.head < original.head->next){
            cout << "IFF" << endl;
            new_list.head = original.head;
            cout << new_list.head->value << endl;
            new_list.head->next = original.head->next;
            cout << new_list.head->next->value << endl;
            cout << "";
        } else {
            cout << "ELSE" << endl;
            new_list.head = original.head->next;
            new_list.head->next = original.head;
        }
        new_list.set_length(2);
        cout << "returning done list" << endl;
        new_list.print();
        return new_list;
    }

    cout << "continuing..." << test << endl;
    
    Linked_List list1, list2;
    Node *temp = original.head; //, *temp1 = list1.head, *temp2 list2.head;

    list1.head = temp;
    Node* temp1 = list1.head;
    cout << "checkpoint" << endl;
    for (int i = 1; i < m; i++){
        cout << temp->value << endl;
        list1.head = temp;
        list1.head = temp1->next;
        temp = temp->next;
    }

    cout << "yeety snowman" << endl;
    //temp1 = temp;
    //temp = temp->next;

    int middle_1;
    if (l + r == 1) {
        middle_1 = l;
    } else {
        middle_1 = (l + m) / 2;
    }
    

    list2.head = temp;
    Node* temp2 = list2.head;

    for (int i = m; i < r - 1; i++){
        temp2 = temp;
        temp = temp->next;
        temp2 = temp1->next;
    }

    temp2 = temp;
    int middle_2 = (m + r) / 2 - 1;
    cout << "left = " << l << " and r = " << r << endl;
    recursive_merge(list1, l, middle_1, m);
    recursive_merge(list2, m, middle_2, r);
}

/*******************************************************************
** Function: get_elements()
** Description: Gets integer inputs from user
** Parameters: none
** Pre-Conditions: None
** Post-Conditions: None
*******************************************************************/ 
int get_elements(){
    bool int_input;
    string temp, temp_choice;
    do{
        int_input = true;
        cout << "Please enter number: ";
        cin >> temp;
        if (is_int(temp) == false){
            cout << "Please enter integer." << endl;
            int_input = false;
        }
    } while (int_input == false);

    return stoi(temp);
}

/*******************************************************************
** Function: get_input()
** Description: gets integers as input from user
** Parameters: none
** Pre-Conditions: None
** Post-Conditions: None
*******************************************************************/ 
/*void get_input(){
    bool good_input;
    string temp, choice;
    do {
        get_elements(list);
        cout << "get_input" << endl;
        do {
            good_input = true;
            cout << "Would you like to add another number? (y or n) ";
            cin >> choice;
            if (choice != "y" && choice != "Y" && choice != "n" && choice != "N"){
                cout << "Please enter valid input" << endl;
                good_input = false;
            }
        } while (good_input == false);
    } while(choice == "y" || choice == "Y");
    list.print();
}
*/

/*******************************************************************
** Function: again()
** Description: checks if user would like to add another integer
** to the linked list.
** Parameters: none
** Pre-Conditions: None
** Post-Conditions: None
*******************************************************************/ 
bool again(){
    string choice;
    do{
        cout << "Would you like to add another number? (y or n) ";
        cin >> choice;
        if (choice != "y" &&  choice != "Y" && choice != "n" && choice != "N"){
            cout << "Please enter valid input." << endl;
        }
    } while (choice != "y" &&  choice != "Y" && choice != "n" && choice != "N");

    if (choice == "y" || choice == "Y")
        return true;
    return false;
}

/*******************************************************************
** Function: function()
** Description: this is where the functionality of the program is called.
** Parameters: none
** Pre-Conditions: None
** Post-Conditions: None
*******************************************************************/ 
void function(){
    Linked_List list;
    bool more_input;
    int length;

    do{
        list.push_back(get_elements());
        more_input = again();
    } while (more_input == true);

    cout << "List created" << endl;
    
    list.print();
    cout << "number of primes: " << list.num_prime() << endl;
}

/*******************************************************************
** Function: main()
** Description: calls function(), and has loop that keeps running program
** while user wants to.
** Parameters: none
** Pre-Conditions: None
** Post-Conditions: None
*******************************************************************/ 
int main(){
    string choice;
    bool good_choice;
    do{
        function();
        do{
            good_choice = true;
            cout << "Would you like to do this again? (y/n) ";
            cin >> choice;
            if (choice != "y" &&  choice != "Y" && choice != "n" && choice != "N"){
                cout << "Please enter a valid input." << endl;
                good_choice = false;
            }
        } while (good_choice == false);
    } while (choice == "y" || choice == "Y");

    return 0;
}