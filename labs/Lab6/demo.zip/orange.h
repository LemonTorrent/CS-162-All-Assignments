#ifndef ORANGE_H
#define ORANGE_H

#include "fruit.h"
#include <string>

using namespace std;

class Orange : public Fruit {

    public:
        Orange();

};

#endif
