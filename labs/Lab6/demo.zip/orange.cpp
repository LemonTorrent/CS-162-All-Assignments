#include "orange.h"

using namespace std;

Orange::Orange() {
    this->name = "Orange";
    this->weight = 5;
}
