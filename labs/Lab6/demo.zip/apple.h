#ifndef APPLE_H
#define APPLE_H

#include "fruit.h"
#include  <string>

using namespace std;

class Apple : public Fruit {

    public:
        Apple();

};

#endif
