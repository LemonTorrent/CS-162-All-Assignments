#include "apple.h"

using namespace std;

Apple::Apple() {
    this->name = "Apple";
    this->weight = 6;
    return;
}
