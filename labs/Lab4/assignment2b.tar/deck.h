/******************************************************************************
 ** Program: deck.h
 ** Author: Nicole Yarbrough
 ** Date: 04/24/2020
 ** Description: This program 
 ** Input: 
 ** Output: 
 *****************************************************************************/ 

#ifndef DECK_H
#define DECK_H

#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <cmath>
#include "./card.h"
//#include "./player.h"
//#include "./game.h"

class Deck{
private:
    //Card card_deck[52];
    Card* card_deck;
    int num_cards;

public:
    Deck();
    //Deck(const Deck&);
    //Deck& operator=(const Deck&);
    ~Deck();


    void create_deck(); //card*);
    void swap(Card&, Card&);
    void shuffle_deck();    //card*);
    Card draw_card();
    Card view_card(int);
    void print_deck();  //card*);
    //int get_deck_index();
    int get_num_cards();


};

#endif