/******************************************************************************
 ** Program: deck.cpp
 ** Author: Nicole Yarbrough
 ** Date: 04/24/2020
 ** Description: This program 
 ** Input: 
 ** Output: 
 *****************************************************************************/ 

#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <cmath>
#include "./card.h"
#include "./deck.h"
//#include "./hand.h"
//#include "./player.h"
//#include "./game.h"

Deck::Deck(){
    num_cards = 52;

    card_deck = new Card [52];
    create_deck();
}

void Deck::create_deck(){   //card* card_deck){
    char suits [4] = {'d','c','h','s'};//"diamond", "club", "heart", "spade"};
    //string ranks [13] = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "jack", "queen", "king"};
    int index;

    for (int i = 0; i < 4; i++){
        for (int j = 0; j < 13; j++){
            index = (i*13) + j;
            card_deck[index].set_suit(suits[i]);
            //card_deck[index].set_suit('d');
            //card_deck[index].suite = suite[i];
            card_deck[index].set_rank(j+1);      //ranks[j]);
            //card_deck[index].set_rank(1);
        }
    }
    cout << "num_cards" << num_cards << endl;
}

void Deck::swap(Card& card_1, Card& card_2){
    Card temp = card_1;
    card_1 = card_2;
    card_2 = temp;
}

void Deck::shuffle_deck(){  //card* card_deck){
    srand (time(NULL));

    for (int i = 0; i < 52; i++){
        int switch_num = rand() % 52;
        swap(card_deck[i], card_deck[switch_num]);
    }
    cout << "num cards = " << num_cards << endl;
}

/*int Deck::get_deck_index(){
    int i = 0;
    while (card_deck[i] != NULL && i < num_cards){
        i += 1;
    }

    return i;
}
*/

Card Deck::draw_card(){
    Card drawn_card;
    int index = num_cards-1;
    
    drawn_card = card_deck[index];
    //card_deck[index] = NULL;
    num_cards -= 1;

    return drawn_card;
}

void Deck::print_deck(){    //card* card_deck){
    for (int i = 0; i < 52; i++){
        cout << card_deck[i].get_rank()
            << card_deck[i].get_suit() << endl;
    }
}

// Three O's


//Card view_card(int index){
    //return card_deck[index];
//}

/*Deck::Deck(const Deck&){
    for (int i = 0; i < num_cards; i++){
        card_deck[i] = old_deck[i];
    }

    return;
}
*/

/*
Deck& Deck::operator=(const Deck& old_deck){
    num_cards = old_deck.size;

    delete [] card_deck;

    card_deck = new Card [num_cards];
    for (int i = 0; i < num_cards; i++){
        card_deck[i] = old_deck[i];
    }

    return *this;
}
*/

Deck::~Deck(){
    delete [] card_deck;
}

int Deck::get_num_cards(){
    cout << "num_cards = " << num_cards << endl;
    return num_cards;
}