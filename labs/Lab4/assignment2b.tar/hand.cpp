/******************************************************************************
 ** Program: hand.cpp
 ** Author: Nicole Yarbrough
 ** Date: 04/24/2020
 ** Description: This program 
 ** Input: 
 ** Output: 
 *****************************************************************************/ 

#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <cmath>
#include "./card.h"
//#include "./deck.h"
#include "./hand.h"
//#include "./player.h"
//#include "./game.h"

using namespace std;

Hand::Hand(){
    card_capacity = 52;
    current_hand = new Card [card_capacity];

    return;
}

void Hand::set_num_cards(const int num){
    num_cards = num;
}

/*Hand::Hand(const Hand& old_hand){
    num_cards = old_hand.num_cards;

    for (int i = 0; i < num_cards; i++){
        current_hand[i] = old_hand.current_hand[i];
    }    

    return;
}

*/

/*
Hand& Hand::operator=(const Hand& old_hand){
    num_cards = old_hand.num_cards;

    delete [] current_hand;

    current_hand = new Hand [num_cards];
    for (int i = 0; i < num_cards; i++){
        current_hand[i] = old_hand.current_hand[i];
    }

    return *this;
}
*/

Hand::~Hand(){
    delete [] current_hand;
}

//void Hand::make_hand(Deck card_deck){

//}

/*int Hand::get_hand_index(){
    int i = 0;
    while (current_hand[i] != NULL && i < num_cards){ // change later when i find out default value of card
        i += 1;
    }

    return i;
}*/

void Hand::add_card(const Card new_card){
    //int index = get_hand_index();
    //current_hand[index] = new_card;
    current_hand[num_cards] = new_card;

    num_cards += 1;
}

int Hand::get_num_cards(){
    return num_cards;
}

int Hand::get_card_index(Card card){ // use when finding card for computer
    for (int i = 0; i < num_cards; i++){
        if (current_hand[i].get_suit() == card.get_suit() || current_hand[i].get_rank() == card.get_rank() || current_hand[i].get_rank() == 8){
            return i;
        }
    }

    return -1;
}

void Hand::play_card(int index, Card& discard_pile){    //Card& card){
    //int index = get_card_index(card);
    //cout << "num_cards = " << num_cards << endl;
    print_hand();

    discard_pile = current_hand[index];

    //for (int i = index + 1; i < num_cards - 1; i++){
    for (int i = index; i < num_cards - 1; i++){
        current_hand[i] = current_hand[i+1];
    }

    //current_hand[num_cards - 1] = NULL;

    num_cards -= 1;
    //discard_pile = current_
    //return current_hand[i]
    //if (discard_pile.get_suit() == 8)
        //wild_8(discard_pile);
    //cout << "num_cards = " << num_cards << endl;
    print_hand();
}

void Hand::print_hand(){
    for (int i = 0; i < num_cards; i++){
        current_hand[i].print_card();
        if (i > 0 && (i % 7) == 0 && i != num_cards - 1){
            cout << endl;
        }
    }

    cout << endl << endl;
}

int Hand::find_card(Card discard_pile){
    //cout << "Find card" << endl;
    //cout << "Hand num_cards = " << num_cards << endl;

    for (int i = 0; i < num_cards; i++){
        //cout << i << endl;
        //cout << current_hand[i].get_suit() << " " << discard_pile.get_suit() << endl;
        //cout << current_hand[i].get_rank() << " " << discard_pile.get_rank() << endl;
        if (current_hand[i].get_suit() == discard_pile.get_suit()){
            
            //cout << "returning..." << endl;
            return i;
        }
        if (current_hand[i].get_rank() == discard_pile.get_suit() || current_hand[i].get_rank() == 8){
            //cout << "returning2..." << endl;
            return i;
        }


    }
    //cout << "returning-1..." << endl;
    return -1;
}