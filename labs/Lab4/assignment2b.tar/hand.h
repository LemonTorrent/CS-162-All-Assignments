/******************************************************************************
 ** Program: hand.h
 ** Author: Nicole Yarbrough
 ** Date: 04/24/2020
 ** Description: This program 
 ** Input: 
 ** Output: 
 *****************************************************************************/ 


#ifndef HAND_H
#define HAND_H

#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <cmath>
#include "./card.h"
//#include "./deck.h"
//#include "./player.h"
//#include "./game.h"

class Hand{
private:
    //int card_capacity, num_cards;

public:
    Card* current_hand;
    int card_capacity, num_cards;


    Hand();
    ~Hand();
    //Hand(const Hand& old_hand);
    //Hand& operator=(const Hand& old_hand);
    //void make_hand(Deck);
    void add_card(Card);
    void set_num_cards(int);
    int find_card(Card);
    //void play_card(Card&);
    void play_card(int, Card&);
    int get_num_cards();
    void print_hand();
    int get_card_index(Card);

};

#endif