#include <iostream>
#include <cmath>
#include "./card.h"
#include "./deck.h"
#include "./hand.h"
#include "./player.h"
#include "./game.h"

using namespace std;

int main(){
	Game crazy8;
	crazy8.play();

	return 0;
}
